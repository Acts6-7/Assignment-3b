
# Project Title

A brief description of what this project does and who it's for

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install foobar
```

## Usage

```python
import foobar

# returns 'words'
foobar.pluralize('word')

# returns 'geese'
foobar.singularize('geese')

# returns 'Colorless green ideas sleep furiously'
foobar.sentence('colorless green ideas sleep furiously')
```

## Contributing

## License

