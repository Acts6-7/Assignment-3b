import numpy as np

# 1
def gaussian_elimination(aug_matrix):
    rows = len(aug_matrix)
    for i in range(rows):
        max_row_index = np.argmax(abs(aug_matrix[i:, i])) + i
        aug_matrix[[i, max_row_index]] = aug_matrix[[max_row_index, i]]

        for k in range(i+1, rows):
            c = -aug_matrix[k][i] / aug_matrix[i][i]
            aug_matrix[k] = aug_matrix[k] + c * aug_matrix[i]

    return aug_matrix

def backward_substitution(aug_matrix):
    rows = len(aug_matrix)
    sol = np.zeros(rows)
    for i in range(rows-1, -1, -1):
        sol[i] = (aug_matrix[i][-1] - np.dot(aug_matrix[i][i+1:rows], sol[i+1:rows])) / aug_matrix[i][i]
    return sol

# 2
def lu_factorization(matrix):
    n = len(matrix)
    L = np.zeros_like(matrix, dtype=float)
    U = np.copy(matrix)
    for i in range(n):
        L[i][i] = 1
        for j in range(i+1, n):
            L[j][i] = U[j][i] / U[i][i]
            U[j] = U[j] - L[j][i] * U[i]
    return L, U

# 3
def is_diagonally_dominant(matrix):
    n = len(matrix)
    for i in range(n):
        sum_row = sum(abs(matrix[i][j]) for j in range(n) if i != j)
        if abs(matrix[i][i]) <= sum_row:
            return False
    return True

# 4
def is_positive_definite(matrix):
    try:
        np.linalg.cholesky(matrix)
        return True
    except np.linalg.LinAlgError:
        return False

def main():
    # 1
    matrix1 = np.array([[2, -1, 1, 6],
                        [1, 3, 1, 0],
                        [-1, 5, 4, -3]], dtype=float)
    upper_tri_matrix = gaussian_elimination(matrix1)
    solution = backward_substitution(upper_tri_matrix)
    print("Solution using Gaussian Elimination and Backward Substitution:")
    print(solution)
    print()

    # 2
    matrix2 = np.array([[1, 1, 0, 3],
                        [2, -1, -1, 1],
                        [3, -1, -1, 2],
                        [-1, 2, 3, -1]], dtype=float)
    L, U = lu_factorization(matrix2)
    print("L matrix from LU Factorization:")
    print(L)
    print("U matrix from LU Factorization:")
    print(U)
    print("Determinant from LU Factorization:")
    print(np.prod(np.diag(U)))
    print()

    # 3
    matrix3 = np.array([[9, 0, 5, 2, 1],
                        [3, 9, 1, 2, 1],
                        [0, 1, 7, 2, 3],
                        [4, 2, 3, 12, 2],
                        [3, 2, 4, 0, 8]], dtype=float)
    diagonal_dominance = is_diagonally_dominant(matrix3)
    print("Matrix is Diagonally Dominant:")
    print(diagonal_dominance)
    print()

    # 4
    matrix4 = np.array([[2, 2, 1],
                        [2, 3, 0],
                        [1, 0, 2]], dtype=float)
    positive_definite = is_positive_definite(matrix4)
    print("Matrix is Positive Definite:")
    print(positive_definite)
    print()

if __name__ == "__main__":
    main()
