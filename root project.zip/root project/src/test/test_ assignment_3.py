import unittest
import numpy as np
import sys

sys.path.append('C:\\Users\\Ryush\\OneDrive\\Desktop\\root project\\src\\main')
from assignment_3 import gaussian_elimination, backward_substitution, lu_factorization, is_diagonally_dominant, is_positive_definite

class TestAssignment3(unittest.TestCase):

    def test_gaussian_elimination(self):
        input_matrix = np.array([[2, -1, 1, 6],
                                 [1, 3, 1, 0],
                                 [-1, 5, 4, -3]], dtype=float)
        result = gaussian_elimination(input_matrix)
        expected = np.array([[1, -0.5, 0.5, 3],
                             [0, 1, 0.57142857, -0.85714286],
                             [0, 0, 1, -1.05]])
        np.testing.assert_array_almost_equal(result, expected, decimal=5)

    def test_backward_substitution(self):
        input_matrix = np.array([[1, -0.5, 0.5, 3],
                                 [0, 1, 0.57142857, -0.85714286],
                                 [0, 0, 1, -1.05]], dtype=float)
        result = backward_substitution(input_matrix)
        expected = np.array([1, -1, -1.05])
        np.testing.assert_array_almost_equal(result, expected, decimal=5)

if __name__ == '__main__':
    unittest.main()
